package ar.edu.ubp.pdc.beans;

public class ProductoBean {

	private String nomProducto;

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}
	
}
